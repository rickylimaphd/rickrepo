plugin.video.myvevo
================


Kodi Addon for VEVO

Version 3.0.8 Krypton or above needed. Added mpd support thru inputstream.adaptive
Version 3.0.7 m3u8 version fix
Version 3.0.6 auth fix
Version 3.0.5 fix playlists, remove live channels, fix navigation
V3.0.4 add Get Related Videos
V3.0.3 improve add to library
V3.0.2 Added initial version of Add to Library
V3.0.1 Isengard version