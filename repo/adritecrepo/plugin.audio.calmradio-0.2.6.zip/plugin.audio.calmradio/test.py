# -*- coding: utf-8 -*-
from api import API
# from user import User
from config import config
import urllib



# user = User(None)
api = API()

# for category in api.get_categories():
#     print category['label']

# for sub_category in api.get_all_subcategories():
#     print sub_category['name']

# for sub_category in api.get_subcategories(1):
#     print sub_category['name']

# for channel in api.get_channels(7):
#     print channel['description']

# print api.add_to_favorites('username', 'password', 9)
# print api.remove_from_favorites('username', 'password', 9)

# for channel in api.get_favorites('username', 'password'):
#     print channel['id']


# print user.authenticate()
# print user.check_sua()

# print api.get_recent_tracks(17, 29, True)

# for channel in api.get_all_categories():
#     urllib.urlretrieve('{0}{1}'.format(config['urls']['calm_arts_host'], channel['image']),
#                        'media{0}'.format(channel['image']))

# for channel in api.get_all_channels():
#     urllib.urlretrieve('{0}{1}'.format(config['urls']['calm_arts_host'], channel['image']),
#                        'media{0}'.format(channel['image']))

# for f in media/arts/*.jpg; do convert $f -resize 1200x800\! $f; done
# for f in media/arts/*.jpg; do convert $f -blur 0x30 $f; done
# for f in media/arts/*.png; do convert $f -resize 1200x800\! $f; done
# for f in media/arts/*.png; do convert $f -blur 0x30 $f; done

