*Canais de TV Adicionados
*Filmes Disponiveis
*Replay
*Rádios
*kids

