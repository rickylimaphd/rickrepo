#!/usr/bin/python
# -*- coding: utf-8 -*-

#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#     ADD-ON FEED NEWS PARA O KODI XBMC - VERSÃO: 1.0.0    #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: YouTube.com/adritecnews                           # 
# SITE: httP://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#           Internacional (CC BY-NC-ND 4.0)'               #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#      FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO        #
#                SEM MINHA ALTORIZAÇÃO                     #
# Add-on desenvolvido para trazer informação para Inscrito #
#          e não inscritos do canal adritec News.          #
#----------------------------------------------------------#

import os, gui, time, datetime, random, urllib2, re
import xbmc, xbmcaddon, xbmcgui, traceback, feedparser
import zlib
import base64

def decode_base64( b64string ):
    decoded_data = base64.b64decode( b64string )
    return zlib.decompress( decoded_data , -15)

def base64_encode( string_val ):
    zlibbed_str = zlib.compress( string_val )
    compressed_string = zlibbed_str[2:-4]
    return base64.b64encode( compressed_string )
	
exec(decode_base64('lVddbuM2EH6uTsENYFDaKIq9WxSpAaPwJk7WQOIsbGcXhRsItETbbGRRJak4adGnnqToQ0/QC7QX65CSZUm2E68AWxQ138zH4fxQ3YuL24Hfv0Dm6iAsA8ES5ZFQMEWDmK7kjNJQ37GVT/qj3njcH1yNQP5pugxIGPLY6+p/m4Wdbq7SsbLRoHvTy5TX8d6cKgPrxzNu45gsKXas9Vv/+vb8AFQi+IxFGpiZ+9QdfzzIXELUAjteSAMeUhunanZyVmj53BuO+reD17U8UiEZjwHYPwf54noVyAKDuuwOusPxwagZiYlQgLvuDq7uule9l3DXPCAR+5WGIyVYPLcs66L34e7qFY4jqhRI27ir2CMRKKRJKsh/f/z7N/z+4thBHYiTGYkkxdaH7qjnX/Z6F4Pel1EWQQulEtk+PVUrpoSU3pKaoaLCTyX8Ke7D9OkP+qGTE8CW9Y2+rJDOUMTn9lLOXRTRRxp1dIh517dXhrvTtjRzNkPZUoDKpWaCSBxm8uhNFpUa0hsOb4dtJKhKRbwGZlKdLSkwiY6BP3IxOkZKkIBOSfDgzbhYEuXTp8B2jA6D0yTXkQ7i+ESDqrGznt2sxbHMAsHJnwRPqFDPtjRb03JRECsRdVpNuPJFZrSNuXnKvC8sDvnKNnKOt0NHxi67jB25y84jiVK6y5wSz+09xvYrymyCb2iiUM/cIBsQkYi2zUYelbAugqhZ8PQNOgK3gCKbOm51G3IPBREl4hAf7ea7Ew6qg4hIiW54zBQXtjGcP+TqtG3fZzDl+7ak0cxFb4mYS7i9fVjpUS6oL/3eS2gcgvbzBYnnFMJ/LFJqFSKFUh7naSUzydBoLynTvsJbUtg5wFphLFveiIpHKC42n/5MA7VvYSXTAnKHL2GTgVXN3vI59w/YWrutJiIVFKTMJi2923ZBRbBGYbWAEo5irmpmPTLlQg3pLymVStNrl2LcZHNNvuagzENV0PbittxqSsoW6GvbXx2/IkyN2ZIiXSYnrbNm0/0eft/B732zeT9hsbJfLshTwQS6hH0a6H7sOPdbNtg85oJ+isjza9X9Q8TBq0RU63lZl7VnrN1uckeboRAQHpN6CGo/s5By21k73lTlMqV9+2GivxwgbgbT7QeaT6xAFdRD6PVhWnSiN3jbx9BUYXnlFNzNXdcM8MZ5KgSNVVY9LhgBHn2IMsRi2KBm69umC//N9/cHMQ4IeyIQ6ihkwO9PkOD6CSjN2HzTQv+hEpEpVCby4gJ2sjdxGywedMe1nYN3qxbuOhAvuejq3LLXUel81e6UVZxW0mfHmqaCkgczaxXVQEFCZ8eSei0oBkSfJjYhCX0YMb0zQpuxW+67s5bTBindtL80JG7khSxYcF1iJhhDJ8f3Gz55QyWT9ruz5v0LpSrgEBaBcUveBdSK0sxNtZJdEnVRf7AR1OSPS7gCtpEAkZAoqmDsFQPoVoke2IWci3CDuKgRosYUNX5EjY/txk27MSp5WoV+pA97SOvcGDjZ6Nd/IY0UgQVBjIWy8x4Kzx5Wa3WazMyQqTHoZwxQI4ETdKQbbGLjZonQtm9u78YHOCffouLNS5uUp8GuRpq/K3sITjfVtJBDEy5A5dXCWyq5OktaFUX6+8gMOmaYEAEHW8/c7MrxuJoYYG0pN7AJhjokGJW4WtShMtGnTOw3k515kOub5t107YhC49HanJOW47imebWbv0/WK7zfspvTNaCJsVCVUUxFNJOxjeoJNlOQTB5U4QiOxjb+KYb8wuUJVZ8Q+UQWIE7VAYmOzcxIVtZKSadt6h2Ar7R0GjG5gKOQUSWTiMHsMXYmzfs9iln1hI0b0kuNMYwaRXfW+2gmK58H60vW8LD6NOK4gLvGHc6LmNzmBmOeq5iUwep1L7q669tHeQx6T8voyEWbz1kXrV8d1eFeyG94SKJaM4BMh5fFVHY+b6MEzodb1dli+mioP7593xwFfH9JWOz7uF2cJZ3/AQ=='))