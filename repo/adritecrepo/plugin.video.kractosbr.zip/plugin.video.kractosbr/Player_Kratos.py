# -*- coding: utf-8 -*-
import urllib
import urllib2
import datetime
import re
import os
import base64
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import cookielib
import sys
import xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
try:
    import json
except:
    import simplejson as json
import SimpleDownloader as downloader
import jsunpack
addon = xbmcaddon.Addon(id='plugin.video.kractosbr')
addon_version = addon.getAddonInfo('version')
profile = xbmc.translatePath(addon.getAddonInfo('profile').decode('utf-8'))
home = xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))
favorites = os.path.join(profile, 'favorites')
history = os.path.join(profile, 'history')
plugin = addon.getSetting('plugin')
REV = os.path.join(profile, 'list_revision')
icon = os.path.join(home, 'icon.png')
icon2 = os.path.join(home, 'icon2.png')
batman = os.path.join(home,'batman.png')
chaves = os.path.join(home,'chaves.png')
FANART = os.path.join(home, 'fanart.jpg')
source_file = os.path.join(profile, 'source_file')
functions_dir = profile
dialog=xbmcgui.Dialog()

def getUrl(url, cookieJar=None,post=None, timeout=20, headers=None):


	cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
	opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
	#opener = urllib2.install_opener(opener)
	req = urllib2.Request(url)
	req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36')
	if headers:
		for h,hv in headers:
			req.add_header(h,hv)

	response = opener.open(req,post,timeout=timeout)
	link=response.read()
	response.close()
	return link;

	
def abrir_url(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except IOError:#     except urllib2.HTTPError, e:
		dialog.notification('','Não foi possivel acessar o servidor.',icon)
		sys.exit(0)
###
#RESOLVERS DIA 10/05/2018
###
def Pre_link_rapidvideo(url):		
	link = abrir_url(url)
	r ='<source src="(.*?)"'
	match = re.compile(r).findall(link)
	for urls in match:
		liz = xbmcgui.ListItem(name, iconImage=iconimage)
		liz.setPath(urls)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
		

def Pre_link_estream(url):		
	link = abrir_url(url)
	r ='''<source src="(.+?)" type='application.+?' />'''
	match = re.compile(r).findall(link)
	for urls in match:
		liz = xbmcgui.ListItem(name, iconImage=iconimage)
		liz.setPath(urls)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
				
def Pre_link_animesonlineq(url):		
	link = abrir_url(url)
	r ='<link itemprop="embedURL" href="(.*?)">'
	match = re.compile(r).findall(link)
	for urls in match:
		liz = xbmcgui.ListItem(name, iconImage=iconimage)
		liz.setPath(urls)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
		
		
###
#RESOLVERS DIA 10/05/2018
###	
def Pre_link_rede_canais(url):		
	link = abrir_url(url)
	r ='<iframe name="Player".*?src="(.*?)".*?allowFullScreen>\s*</iframe>'
	match = re.compile(r).findall(link)
	for urls in match:
		links = abrir_url(urls)
		matchs = re.compile('file: "(.*?)",').findall(links)[0]
		liz = xbmcgui.ListItem(name, iconImage=iconimage)
	#	liz.setInfo(type='Video', infoLabels={'Title':name})
	#	liz.setProperty("IsPlayable","true")
		plays  = matchs+"|Referer="+urls
		liz.setPath(plays)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def Pre_link_pipocao(url):
	link  = abrir_url(url)
	urls = []
	names = []
	#m18 = re.findall(",'https://lh3(.*?)=m18'.*?'360p',",link)[0]
	#m22 = re.findall("','https://lh3(.*?)=m22'.*?,'720p',",link)[0]
	#m37 = re.findall(".*?'.*?','https://lh3(.*?)=m22'.*?,'1080p'",link)[0]	
	m18 = re.compile(r"createEmbedSource.*?'','.*?','.*?',.*?,'(.*?)','.*?','.*?','360p','.*?>").findall(link)
	m22 = re.compile(r"createEmbedSource.*?'','.*?','.*?',.*?,'.*?','(.*?)','.*?','.*?','720p','.*?>").findall(link)
	m37 = re.compile(r"createEmbedSource.*?'','.*?','.*?',.*?,'.*?','.*?','(.*?)','.*?','.*?','1080p'.*?>").findall(link)
	if ('=m18' in link):
		uri = m18
		nome = '360p'
		urls.append(uri)
		names.append(nome)
	if ('=m22' in link):
		uri = m22
		nome = '720p'
		urls.append(uri)
		names.append(nome)
	if ('=m37' in link):
		uri = m37
		nome = '1080p'
		urls.append(uri)
		names.append(nome)
	opcao = xbmcgui.Dialog().select('-=Kratos Kodi Br =-', names)
	if opcao>= 0:
		link = urls[opcao]
		linkss = link[0]
		liz = xbmcgui.ListItem(name, iconImage=iconimage)
	#	liz.setInfo(type='Video', infoLabels={'Title':name})
	#	liz.setProperty("IsPlayable","true")
		liz.setPath(linkss)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	else:
		sys.exit()
		
def Pre_link_netcine(url):
	a = abrir_url(url)
	b = re.compile('<iframe src="(.*?)"').findall(a)[0]
	link = abrir_url(b)
	reg = re.compile('file: "(.*?)"').findall(link)
	items_url = []
	items_name = []
	for url in reg:
		if 'ALTO' in url:
			items_names = 'Qualidade Alta'
			items_name.append(items_names)
			items_url.append(url)
		elif 'BAIXO' in url:
			items_names = 'Qualidade Baixa'
			items_name.append(items_names)		
			items_url.append(url)		
	opcao = xbmcgui.Dialog().select('-=Kratos Kodi Br =-', items_name)
	if opcao>= 0:
		linkss = items_url[opcao] 
		linkss+='|Referer=http://netcine.us/'
		liz = xbmcgui.ListItem(name, iconImage=iconimage)
	#	liz.setInfo(type='Video', infoLabels={'Title':name})
	#	liz.setProperty("IsPlayable","true")
		liz.setPath(linkss)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	else:
		sys.exit()

		
def Pre_link_mmfilmes(url):
	referer = [('Referer','http://www.mmfilmes.tv/')]#getUrl(page_value,headers=referer)
	a =  getUrl(url, headers=referer)
	b = re.compile("addiframe.*?'(.*?)'").findall(a)[0]
	c = getUrl(b, headers=referer)
	items_url = []
	items_name = []
	match = re.compile("{'file':'(.*?)'.*?'label").findall(c)
	for url in  set(match):
		if '360p' in url:
			items_names = '360p'
			items_name.append(items_names)
			items_url.append(url)
		elif '480p' in url:
			items_names = '480p'
			items_name.append(items_names)		
			items_url.append(url)		
		elif '720p' in url:
			items_names = '720p'
			items_name.append(items_names)		
			items_url.append(url)		
	opcao = xbmcgui.Dialog().select('-=Kratos Kodi Br =-', items_name)
	if opcao>= 0:
		linkss = items_url[opcao] 
		linkss+='|Referer=http://www.mmfilmes.tv/'
		liz = xbmcgui.ListItem(name, iconImage=iconimage)
	#	liz.setInfo(type='Video', infoLabels={'Title':name})
	#	liz.setProperty("IsPlayable","true")
		liz.setPath(linkss)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	else:
		sys.exit()

def Pre_link_seuseriado(url):
	url = url.replace('#038;','')
	referer = [('Referer','https://seuseriado.com/')]#'https://seuseriado.com/')]#getUrl(page_value,headers=referer)
	link =		''
	items_url = []
	items_name = []
	match = re.compile("'(https.*?)','(.*?)'").findall(link)
	for urls,names in match:
		urls = urls.replace('/r.php?','/redirect.php?')
		items_name.append(names)		
		items_url.append(urls)			
	opcao = xbmcgui.Dialog().select('-=Kratos Kodi Br =-', items_name)
	if opcao>= 0:
		linkss = items_url[opcao] 
		#linkss+='|Referer=http://www.mmfilmes.tv/'
		liz = xbmcgui.ListItem(name, iconImage=iconimage)
	#	liz.setInfo(type='Video', infoLabels={'Title':name})
	#	liz.setProperty("IsPlayable","true")
		liz.setPath(linkss)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	else:
		sys.exit()	
def Check_update():
	versao='2.0'
	Source_Update = os.path.join(home, 'Player_Kratos.py')
	base_update = abrir_url('https://raw.githubusercontent.com/brunolojino/listas/master/Kratos_Update.txt')
	check = re.compile("versao='(.*?)'").findall(base_update)[0]
	if versao==check:
		pass
	else:
		f = open(Source_Update, 'wb')
		f.write(base_update)
		f.close()
		dialog.ok('-=Kratos Kodi Br =-','Versão do player: '+versao,'Versão do player disponível: '+check,'Atualizando o player do add-on feche e abra novamente.')
		sys.exit(0) 
def Other(url):
	url2 = url
	liz = xbmcgui.ListItem(name, iconImage=iconimage)
	liz.setPath(url2)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)		
Rsolvers_Kratos = ['pipocao.com','redecanais.','netcine.us','mmfilmes.tv','rapidvideo.com','estream.nu','estream.to','animesonlineq.net','Other://']	
def Resolvers(url,name,iconimage):   	
	rURL = url.replace(';','')
	if 'pipocao.com' in rURL and not 'Other://' in rURL:
		link = rURL
		Pre_link_pipocao(link)		
	elif 'redecanais' in rURL and not 'Other://' in rURL:
		link = rURL
		Pre_link_rede_canais(link)
	elif 'netcine.us' in rURL and not 'Other://' in rURL:
		link = rURL
		xbmc.log(link)
		Pre_link_netcine(link)	
	elif 'mmfilmes.tv' in rURL and not 'Other://' in rURL:
		link = rURL
		xbmc.log(link)
		Pre_link_mmfilmes(link)					
	elif 'rapidvideo.com' in rURL and not 'Other://' in rURL:
		link = rURL
		xbmc.log(link)
		Pre_link_rapidvideo(link)				
	elif 'estream.nu' in rURL or 'estream.to' in rURL and not 'Other://' in rURL:
		link = rURL
		xbmc.log(link)
		Pre_link_estream(link)					
	elif 'animesonlineq.net' in rURL and not 'Other://' in rURL:
		link = rURL
		xbmc.log(link)
		Pre_link_animesonlineq(link)			
	elif 'Other://' in rURL:
		link = rURL
		link = link.replace('Other://','')
		Other(link)			

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                splitparams={}
                splitparams=pairsofparams[i].split('=')
                if (len(splitparams))==2:
                    param[splitparams[0]]=splitparams[1]
        return param
		
params=get_params()

url=None
name=None
iconimage=None
fanart=FANART
try:
    url=urllib.unquote_plus(params["url"]).decode('utf-8')
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
