# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint

addonID = 'plugin.video.narutoshipuden'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'

valor = 100
addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close

i = randint(1,276)

#277 a 281 server 2
        
for j in range(i,valor+i):
        
        file = open(""+m3u+"","a")
        igvar = "%03d" %(j+1)
        gvar = str(igvar)

        file.write("http://cdnv2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/NRTOSHPEP"+gvar+".mp4")
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

