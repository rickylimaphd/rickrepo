from random import randint
temp = randint(1,22)
print(temp)

eps = [13,22,24,22,22,25,25,25,25,23,22,21,22,22,22,21,22,22,20,23,22,22]

valor = eps[temp - 1]

print (valor)
