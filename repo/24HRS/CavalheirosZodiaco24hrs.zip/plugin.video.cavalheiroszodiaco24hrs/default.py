# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint
import base64
import naomi

addonID = 'plugin.video.cavalheiroszodiaco24hrs'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'

tunel = "UmVmZXJlcj1odHRwOi8vd3d3LnJlZGVjYW5haXMuY29tLmJyLw=="
ftunel = base64.b64decode(tunel)

addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(0,145)
ieps = 145 - eps

eng2sp = {0:"http://fabiolmg.local/RCServer01/videos/OCDZEP000.mp4|"+ftunel+"",
1:"http://fabiolmg.local/RCServer01/videos/OCDZEP001.mp4|"+ftunel+"",
2:"http://fabiolmg.local/RCServer01/videos/OCDZEP002.mp4|"+ftunel+"",
3:"http://fabiolmg.local/RCServer01/videos/OCDZEP003.mp4|"+ftunel+"",
4:"http://fabiolmg.local/RCServer01/videos/OCDZEP004.mp4|"+ftunel+"",
5:"http://fabiolmg.local/RCServer01/videos/OCDZEP005.mp4|"+ftunel+"",
6:"http://fabiolmg.local/RCServer01/videos/OCDZEP006.mp4|"+ftunel+"",
7:"http://fabiolmg.local/RCServer01/videos/OCDZEP007.mp4|"+ftunel+"",
8:"http://fabiolmg.local/RCServer01/videos/OCDZEP008.mp4|"+ftunel+"",
9:"http://fabiolmg.local/RCServer01/videos/OCDZEP009.mp4|"+ftunel+"",
10:"http://fabiolmg.local/RCServer01/videos/OCDZEP010.mp4|"+ftunel+"",
11:"http://fabiolmg.local/RCServer01/videos/OCDZEP011.mp4|"+ftunel+"",
12:"http://fabiolmg.local/RCServer01/videos/OCDZEP012.mp4|"+ftunel+"",
13:"http://fabiolmg.local/RCServer01/videos/OCDZEP013.mp4|"+ftunel+"",
14:"http://fabiolmg.local/RCServer01/videos/OCDZEP014.mp4|"+ftunel+"",
15:"http://fabiolmg.local/RCServer01/videos/OCDZEP015.mp4|"+ftunel+"",
16:"http://fabiolmg.local/RCServer01/videos/OCDZEP016.mp4|"+ftunel+"",
17:"http://fabiolmg.local/RCServer01/videos/OCDZEP017.mp4|"+ftunel+"",
18:"http://fabiolmg.local/RCServer01/videos/OCDZEP018.mp4|"+ftunel+"",
19:"http://fabiolmg.local/RCServer01/videos/OCDZEP019.mp4|"+ftunel+"",
20:"http://fabiolmg.local/RCServer01/videos/OCDZEP020.mp4|"+ftunel+"",
21:"http://fabiolmg.local/RCServer01/videos/OCDZEP021.mp4|"+ftunel+"",
22:"http://fabiolmg.local/RCServer01/videos/OCDZEP022.mp4|"+ftunel+"",
23:"http://fabiolmg.local/RCServer01/videos/OCDZEP023.mp4|"+ftunel+"",
24:"http://fabiolmg.local/RCServer01/videos/OCDZEP024.mp4|"+ftunel+"",
25:"http://fabiolmg.local/RCServer01/videos/OCDZEP025.mp4|"+ftunel+"",
26:"http://fabiolmg.local/RCServer01/videos/OCDZEP026.mp4|"+ftunel+"",
27:"http://fabiolmg.local/RCServer01/videos/OCDZEP027.mp4|"+ftunel+"",
28:"http://fabiolmg.local/RCServer01/videos/OCDZEP028.mp4|"+ftunel+"",
29:"http://fabiolmg.local/RCServer01/videos/OCDZEP029.mp4|"+ftunel+"",
30:"http://fabiolmg.local/RCServer01/videos/OCDZEP030.mp4|"+ftunel+"",
31:"http://fabiolmg.local/RCServer01/videos/OCDZEP031.mp4|"+ftunel+"",
32:"http://fabiolmg.local/RCServer01/videos/OCDZEP032.mp4|"+ftunel+"",
33:"http://fabiolmg.local/RCServer01/videos/OCDZEP033.mp4|"+ftunel+"",
34:"http://fabiolmg.local/RCServer01/videos/OCDZEP034.mp4|"+ftunel+"",
35:"http://fabiolmg.local/RCServer01/videos/OCDZEP035.mp4|"+ftunel+"",
36:"http://fabiolmg.local/RCServer01/videos/OCDZEP036.mp4|"+ftunel+"",
37:"http://fabiolmg.local/RCServer01/videos/OCDZEP037.mp4|"+ftunel+"",
38:"http://fabiolmg.local/RCServer01/videos/OCDZEP038.mp4|"+ftunel+"",
39:"http://fabiolmg.local/RCServer01/videos/OCDZEP039.mp4|"+ftunel+"",
40:"http://fabiolmg.local/RCServer01/videos/OCDZEP040.mp4|"+ftunel+"",
41:"http://fabiolmg.local/RCServer01/videos/OCDZEP041.mp4|"+ftunel+"",
42:"http://fabiolmg.local/RCServer01/videos/OCDZEP042.mp4|"+ftunel+"",
43:"http://fabiolmg.local/RCServer01/videos/OCDZEP043.mp4|"+ftunel+"",
44:"http://fabiolmg.local/RCServer01/videos/OCDZEP044.mp4|"+ftunel+"",
45:"http://fabiolmg.local/RCServer01/videos/OCDZEP045.mp4|"+ftunel+"",
46:"http://fabiolmg.local/RCServer01/videos/OCDZEP046.mp4|"+ftunel+"",
47:"http://fabiolmg.local/RCServer01/videos/OCDZEP047.mp4|"+ftunel+"",
48:"http://fabiolmg.local/RCServer01/videos/OCDZEP048.mp4|"+ftunel+"",
49:"http://fabiolmg.local/RCServer01/videos/OCDZEP049.mp4|"+ftunel+"",
50:"http://fabiolmg.local/RCServer01/videos/OCDZEP050.mp4|"+ftunel+"",
51:"http://fabiolmg.local/RCServer01/videos/OCDZEP051.mp4|"+ftunel+"",
52:"http://fabiolmg.local/RCServer01/videos/OCDZEP052.mp4|"+ftunel+"",
53:"http://fabiolmg.local/RCServer01/videos/OCDZEP053.mp4|"+ftunel+"",
54:"http://fabiolmg.local/RCServer01/videos/OCDZEP054.mp4|"+ftunel+"",
55:"http://fabiolmg.local/RCServer01/videos/OCDZEP055.mp4|"+ftunel+"",
56:"http://fabiolmg.local/RCServer01/videos/OCDZEP056.mp4|"+ftunel+"",
57:"http://fabiolmg.local/RCServer01/videos/OCDZEP057.mp4|"+ftunel+"",
58:"http://fabiolmg.local/RCServer01/videos/OCDZEP058.mp4|"+ftunel+"",
59:"http://fabiolmg.local/RCServer01/videos/OCDZEP059.mp4|"+ftunel+"",
60:"http://fabiolmg.local/RCServer01/videos/OCDZEP060.mp4|"+ftunel+"",
61:"http://fabiolmg.local/RCServer01/videos/OCDZEP061.mp4|"+ftunel+"",
62:"http://fabiolmg.local/RCServer01/videos/OCDZEP062.mp4|"+ftunel+"",
63:"http://fabiolmg.local/RCServer01/videos/OCDZEP063.mp4|"+ftunel+"",
64:"http://fabiolmg.local/RCServer01/videos/OCDZEP064.mp4|"+ftunel+"",
65:"http://fabiolmg.local/RCServer01/videos/OCDZEP065.mp4|"+ftunel+"",
66:"http://fabiolmg.local/RCServer01/videos/OCDZEP066.mp4|"+ftunel+"",
67:"http://fabiolmg.local/RCServer01/videos/OCDZEP067.mp4|"+ftunel+"",
68:"http://fabiolmg.local/RCServer01/videos/OCDZEP068.mp4|"+ftunel+"",
69:"http://fabiolmg.local/RCServer01/videos/OCDZEP069.mp4|"+ftunel+"",
70:"http://fabiolmg.local/RCServer01/videos/OCDZEP070.mp4|"+ftunel+"",
71:"http://fabiolmg.local/RCServer01/videos/OCDZEP071.mp4|"+ftunel+"",
72:"http://fabiolmg.local/RCServer01/videos/OCDZEP072.mp4|"+ftunel+"",
73:"http://fabiolmg.local/RCServer01/videos/OCDZEP073.mp4|"+ftunel+"",
74:"http://fabiolmg.local/RCServer01/videos/OCDZEP074.mp4|"+ftunel+"",
75:"http://fabiolmg.local/RCServer01/videos/OCDZEP075.mp4|"+ftunel+"",
76:"http://fabiolmg.local/RCServer01/videos/OCDZEP076.mp4|"+ftunel+"",
77:"http://fabiolmg.local/RCServer01/videos/OCDZEP077.mp4|"+ftunel+"",
78:"http://fabiolmg.local/RCServer01/videos/OCDZEP078.mp4|"+ftunel+"",
79:"http://fabiolmg.local/RCServer01/videos/OCDZEP079.mp4|"+ftunel+"",
80:"http://fabiolmg.local/RCServer01/videos/OCDZEP080.mp4|"+ftunel+"",
81:"http://fabiolmg.local/RCServer01/videos/OCDZEP081.mp4|"+ftunel+"",
82:"http://fabiolmg.local/RCServer01/videos/OCDZEP082.mp4|"+ftunel+"",
83:"http://fabiolmg.local/RCServer01/videos/OCDZEP083.mp4|"+ftunel+"",
84:"http://fabiolmg.local/RCServer01/videos/OCDZEP084.mp4|"+ftunel+"",
85:"http://fabiolmg.local/RCServer01/videos/OCDZEP085.mp4|"+ftunel+"",
86:"http://fabiolmg.local/RCServer01/videos/OCDZEP086.mp4|"+ftunel+"",
87:"http://fabiolmg.local/RCServer01/videos/OCDZEP087.mp4|"+ftunel+"",
88:"http://fabiolmg.local/RCServer01/videos/OCDZEP088.mp4|"+ftunel+"",
89:"http://fabiolmg.local/RCServer01/videos/OCDZEP089.mp4|"+ftunel+"",
90:"http://fabiolmg.local/RCServer01/videos/OCDZEP090.mp4|"+ftunel+"",
91:"http://fabiolmg.local/RCServer01/videos/OCDZEP091.mp4|"+ftunel+"",
92:"http://fabiolmg.local/RCServer01/videos/OCDZEP092.mp4|"+ftunel+"",
93:"http://fabiolmg.local/RCServer01/videos/OCDZEP093.mp4|"+ftunel+"",
94:"http://fabiolmg.local/RCServer01/videos/OCDZEP094.mp4|"+ftunel+"",
95:"http://fabiolmg.local/RCServer01/videos/OCDZEP095.mp4|"+ftunel+"",
96:"http://fabiolmg.local/RCServer01/videos/OCDZEP096.mp4|"+ftunel+"",
97:"http://fabiolmg.local/RCServer01/videos/OCDZEP097.mp4|"+ftunel+"",
98:"http://fabiolmg.local/RCServer01/videos/OCDZEP098.mp4|"+ftunel+"",
99:"http://fabiolmg.local/RCServer01/videos/OCDZEP099.mp4|"+ftunel+"",
100:"http://fabiolmg.local/RCServer01/videos/OCDZEP100.mp4|"+ftunel+"",
101:"http://fabiolmg.local/RCServer01/videos/OCDZEP101.mp4|"+ftunel+"",
102:"http://fabiolmg.local/RCServer01/videos/OCDZEP102.mp4|"+ftunel+"",
103:"http://fabiolmg.local/RCServer01/videos/OCDZEP103.mp4|"+ftunel+"",
104:"http://fabiolmg.local/RCServer01/videos/OCDZEP104.mp4|"+ftunel+"",
105:"http://fabiolmg.local/RCServer01/videos/OCDZEP105.mp4|"+ftunel+"",
106:"http://fabiolmg.local/RCServer01/videos/OCDZEP106.mp4|"+ftunel+"",
107:"http://fabiolmg.local/RCServer01/videos/OCDZEP107.mp4|"+ftunel+"",
108:"http://fabiolmg.local/RCServer01/videos/OCDZEP108.mp4|"+ftunel+"",
109:"http://fabiolmg.local/RCServer01/videos/OCDZEP109.mp4|"+ftunel+"",
110:"http://fabiolmg.local/RCServer01/videos/OCDZEP110.mp4|"+ftunel+"",
111:"http://fabiolmg.local/RCServer01/videos/OCDZEP111.mp4|"+ftunel+"",
112:"http://fabiolmg.local/RCServer01/videos/OCDZEP112.mp4|"+ftunel+"",
113:"http://fabiolmg.local/RCServer01/videos/OCDZEP113.mp4|"+ftunel+"",
114:"http://fabiolmg.local/RCServer01/videos/OCDZEP114.mp4|"+ftunel+"",
115:"http://fabiolmg.local/RCServer01/videos/OCDZEP115.mp4|"+ftunel+"",
116:"http://fabiolmg.local/RCServer01/videos/OCDZEP116.mp4|"+ftunel+"",
117:"http://fabiolmg.local/RCServer01/videos/OCDZEP117.mp4|"+ftunel+"",
118:"http://fabiolmg.local/RCServer01/videos/OCDZEP118.mp4|"+ftunel+"",
119:"http://fabiolmg.local/RCServer01/videos/OCDZEP119.mp4|"+ftunel+"",
120:"http://fabiolmg.local/RCServer01/videos/OCDZEP120.mp4|"+ftunel+"",
121:"http://fabiolmg.local/RCServer01/videos/OCDZEP121.mp4|"+ftunel+"",
122:"http://fabiolmg.local/RCServer01/videos/OCDZEP122.mp4|"+ftunel+"",
123:"http://fabiolmg.local/RCServer01/videos/OCDZEP123.mp4|"+ftunel+"",
124:"http://fabiolmg.local/RCServer01/videos/OCDZEP124.mp4|"+ftunel+"",
125:"http://fabiolmg.local/RCServer01/videos/OCDZEP125.mp4|"+ftunel+"",
126:"http://fabiolmg.local/RCServer01/videos/OCDZEP126.mp4|"+ftunel+"",
127:"http://fabiolmg.local/RCServer01/videos/OCDZEP127.mp4|"+ftunel+"",
128:"http://fabiolmg.local/RCServer01/videos/OCDZEP128.mp4|"+ftunel+"",
129:"http://fabiolmg.local/RCServer01/videos/OCDZEP129.mp4|"+ftunel+"",
130:"http://fabiolmg.local/RCServer01/videos/OCDZEP130.mp4|"+ftunel+"",
131:"http://fabiolmg.local/RCServer01/videos/OCDZEP131.mp4|"+ftunel+"",
132:"http://fabiolmg.local/RCServer01/videos/OCDZEP132.mp4|"+ftunel+"",
133:"http://fabiolmg.local/RCServer01/videos/OCDZEP133.mp4|"+ftunel+"",
134:"http://fabiolmg.local/RCServer01/videos/OCDZEP134.mp4|"+ftunel+"",
135:"http://fabiolmg.local/RCServer01/videos/OCDZEP135.mp4|"+ftunel+"",
136:"http://fabiolmg.local/RCServer01/videos/OCDZEP136.mp4|"+ftunel+"",
137:"http://fabiolmg.local/RCServer01/videos/OCDZEP137.mp4|"+ftunel+"",
138:"http://fabiolmg.local/RCServer01/videos/OCDZEP138.mp4|"+ftunel+"",
139:"http://fabiolmg.local/RCServer01/videos/OCDZEP139.mp4|"+ftunel+"",
140:"http://fabiolmg.local/RCServer01/videos/OCDZEP140.mp4|"+ftunel+"",
141:"http://fabiolmg.local/RCServer01/videos/OCDZEP141.mp4|"+ftunel+"",
142:"http://fabiolmg.local/RCServer01/videos/OCDZEP142.mp4|"+ftunel+"",
143:"http://fabiolmg.local/RCServer01/videos/OCDZEP143.mp4|"+ftunel+"",
144:"http://fabiolmg.local/RCServer01/videos/OCDZEP144.mp4|"+ftunel+"",
145:"http://fabiolmg.local/RCServer02/ondemand/OCDZEP145.mp4|"+ftunel+"",
}

        
for j in range(eps,(eps+25)):
        
        file = open(""+m3u+"","a")
        eps = naomi.getserver(eng2sp[j])
        file.write(eps)
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

