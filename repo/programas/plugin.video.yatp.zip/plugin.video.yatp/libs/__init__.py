# -*- coding: utf-8 -*-
# Module: __init__.py
# Author: Roman V.M.
# Created on: 16.06.2015
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
YATP plugin modules
"""