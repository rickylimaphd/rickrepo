burst.providers package
=======================

.. automodule:: burst.providers
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

burst.providers.burst_overrides module
--------------------------------------

.. automodule:: burst.providers.burst_overrides
    :members:
    :undoc-members:
    :show-inheritance:

burst.providers.definitions module
----------------------------------

.. automodule:: burst.providers.definitions
    :members:
    :undoc-members:
    :show-inheritance:

burst.providers.helpers module
------------------------------

.. automodule:: burst.providers.helpers
    :members:
    :undoc-members:
    :show-inheritance:


