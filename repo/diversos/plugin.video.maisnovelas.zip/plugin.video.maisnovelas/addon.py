#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


##############BIBLIOTECAS A IMPORTAR E DEFINICOES####################

import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,xbmcvfs,socket,HTMLParser
import json
h = HTMLParser.HTMLParser()



addon_id = 'plugin.video.maisnovelas'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = '/resources/img/'
base_url = 'http://www.maisnovelas.net/'



################################################## 

#MENUS############################################

def ULTIMOS():
    addDir('Últimos Adicionados',base_url,6,addonfolder + '/icon.png',True)
    #(name,url,mode,iconimage,folder)
    addDir('Categorias',base_url,4,addonfolder + '/icon.png',True)
    
def alterar_vista():
	try: codigo_fonte = abrir_url(url)
	except: codigo_fonte = ''
	if codigo_fonte:
		match = re.compile('class="level-0" value="(.+?)">(.+?)</option>').findall(codigo_fonte)
		for cat,titulo in match:
			addDir(titulo,url + '?cat=' + str(cat),2,addonfolder+artfolder+'maisnovelas.png',True)

def listar_episodios(url):
    try:
        codigo_fonte = abrir_url(url)
    except:
        codigo_fonte = ''
    if codigo_fonte:
	html_source_trunk = re.findall('Click here to instantly play this video(.*?)</h2></div>', codigo_fonte, re.DOTALL)
	for trunk in html_source_trunk:
		urletitulo = re.compile('href="(.+?)">(.+?)</a>').findall(trunk)
		img = re.compile('src="(.+?)"').findall(trunk)
		print urletitulo,img
		try:
			addDir(urletitulo[1][0].replace('&#8211;','').replace(base_url,"").replace("/","").replace("-"," ").capitalize(),urletitulo[0][0],3,img[0],False)
		except: pass
    try:
        match = re.compile('<a class="nextpostslink" href="(.*?)">').findall(codigo_fonte)
        for urlnext in match:
            print urlnext
            addDir('Próximos >>',urlnext,2,addonfolder + '/icon.png',True)
    except:
        pass

def procurar_fontes(url):
	i=0
	liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setProperty('mimetype', 'video/x-msvideo')
	liz.setProperty('IsPlayable', 'true')
	playlist = xbmc.PlayList(1)
	playlist.clear()
	print url
	try:
		codigo_fonte = abrir_url(url)
	except: codigo_fonte = ''
	if codigo_fonte:
		html_source_trunk = re.findall('<iframe(.*?)</iframe>', codigo_fonte, re.DOTALL)
		for trunk in html_source_trunk:
			try:
				iframe = re.compile('src="(.+?)"').findall(trunk)[0]
				print iframe
			except: iframe = ''
			if iframe:
            			if iframe.find('youtube') > -1:
                			i += 1
                			playlist.add(youtube_resolver(iframe),xbmcgui.ListItem(name, thumbnailImage=iconimage))
            			elif iframe.find('dailymotion') > -1:
                			i += 1
                			print "tem dailymotion"
                			playlist.add(daily_resolver(iframe),xbmcgui.ListItem(name, thumbnailImage=iconimage))
           			elif iframe.find('r7.com') > -1:
               				i += 1
                			playlist.add(r7_resolver(iframe),xbmcgui.ListItem(name, thumbnailImage=iconimage))
            			elif iframe.find('g1novelas-sbt') > -1:
                			i += 1
                			playlist.add(sbt_resolver(iframe),xbmcgui.ListItem(name, thumbnailImage=iconimage))
          		 	else: 
                			coiso = 'outro'
                			#addDir(coiso,'',2,'')

		match = re.compile('<embed id="player_.+?" width=".+?" height=".+?" type="application/x-shockwave-flash" src="(.+?)"').findall(codigo_fonte)
		for embed in match:
			addDir('embed','',2,'',False)
	xbmc.Player().play(playlist)

def youtube_resolver(url):
    match = re.compile('.*/(.+?)\?').findall(url)
    if match:
        return 'plugin://plugin.video.youtube/?action=play_video&videoid=' + str(match[0])
    else: return 'youtube_nao_resolvido'
    
def daily_resolver(url):
    print url
    if url.find('syndication') > -1: match = re.compile('/embed/video/(.+?)\?syndication').findall(url)
    else: match = re.compile('/embed/video/(.*)').findall(url)
    if match:
        return 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=' + str(match[0])
    else: return 'daily_nao resolvido'

def r7_resolver(url):
    source = abrir_url(url)
    match = re.compile("media src='(.+?)'").findall(source)
    if match: return match[0]
    else: return 'r7_nao_resolvido'
    
def sbt_resolver(url):
    print abrir_url('http://www.cdnbr.biz/mastertv/SBT.html')
    try:
        source = abrir_url(url)
    except:
        source = ''
    print url
    if source: 
        match = re.compile('<iframe width=".+?" height=".+?" src="\n(.+?)"').findall(source)
        print match[0]
        try:
            source = abrir_url(match[0])
        except: source = ''
        if source:
            match = re.compile('<iframe.+?src="(.+?)".+?</iframe>').findall(source)
            playpath = match[0]
            print playpath
            try:
                source = abrir_url(match[0])
                print source
            except:
                source = ''
            if source:
                match = re.compile("value='file=(.+?)&streamer=(.+?)&")
                print 'match',match
                for ficheiro,streamer in match:
                    resolved_url = str(streamer + ' playpath=' + ficheiro + 'swfUrl=http://www.cdnbr.biz/swf/player.swf live=1 pageUrl=' + playpath)
                    print resolved_url
                    return resolved_url
                

###################################################################################
#FUNCOES

###################################################################################
#FUNCOES JÁ FEITAS


def abrir_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link


def addDir(name,url,mode,iconimage,folder):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder +'/fanart.jpg')
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=folder)
        return ok

############################################################################################################
#                                               GET PARAMS                                                 #
############################################################################################################
              
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

      
params=get_params()
url=None
name=None
mode=None
iconimage=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Iconimage: "+str(iconimage)




###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################


if mode==None or url==None or len(url)<1:
        print ""
        ULTIMOS()

elif mode==1:
    ULTIMOS()

elif mode==2:
    listar_episodios(url)

elif mode==3:
    procurar_fontes(url)
    
elif mode==4:
    alterar_vista()

elif mode==6:
    listar_episodios(base_url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
