#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os
import urlresolver
import sys
from BeautifulSoup import BeautifulSoup


pluginhandle = int(sys.argv[1])

versao = '1.0'
addon_base = 'MEU-GUIA.TV'
addon_id = 'plugin.video.MEU-GUIA.TV'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
fanart = addonfolder + '/fanart.jpg'
icones = addonfolder + '/icon.png'
base = 'http://megafilmeshd21.net/'
base2 = 'https://meuguia.tv'
wizard_create = selfAddon.getSetting('wizard_create')
local_wizard = xbmc.translatePath(os.path.join(wizard_create))


############################################################################################################
#                                           LISTAR VIDEOS                                                
############################################################################################################
		
def contar_acessos():
	req = urllib2.Request('https://goo.gl/sb9b22')
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
def cleanTitle(title):
    title = title.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&#038;", "&").replace("&#39;", "'")
    title = title.replace("&#039;", "'").replace("&#8211;", "-").replace("&#8220;", "-").replace("&#8221;", "-").replace("&#8217;", "'")
    title = title.replace("&quot;", "\"").replace("&uuml;", "ü").replace("&auml;", "ä").replace("&ouml;", "ö")
    title = title.strip()
    return title
	
def categorias(url):
	contar_acessos()
	link = abrir_url('https://meuguia.tv/')
	link = BeautifulSoup(link, convertEntities=BeautifulSoup.HTML_ENTITIES)
	match = link.find('div',{'class':'mw content'}).findAll('a')
	for i in match:
		url = i['href']
		name = i.h2.string.encode('utf-8')
		name = cleanTitle(name)
		cate_name = i.h3.string.encode('utf-8')
		cate_name = cleanTitle(cate_name)
		if selfAddon.getSetting('startup') == "0":
			addDir('[COLOR lime]\n|>   [/COLOR]'+'  [COLOR darkseagreen]%s[/COLOR]'%name+'   [COLOR lime]  < - >  [/COLOR]    ''[COLOR white]'+cate_name+'[/COLOR]'+'[COLOR lime]   <|[/COLOR]',base2+url,2,artfolder + 'icon.png')
		elif selfAddon.getSetting('startup') == "1":
			addDir('[COLOR white]'+name+':[/COLOR]\n[COLOR darkseagreen]'+cate_name+'[/COLOR]\n',base2+url,2,artfolder + 'icon.png')
	#match = re.compile('<a href="(.*?)">\s*(.*?)<br />\s*<span class="metadados">(.*?)</span>').findall(link)
	#for url,name,cate_name in match:
		#name = name.replace('S&eacute;ries','Séries').replace('Document&aacute;rios','Documentários').replace('Not&iacute;','Notícias').replace('Notíciascias','Notícias')
		#cate_name = cate_name.replace('Veja tudo que est&aacute; passando agora na TV!','Veja tudo que está passando agora na TV!')


		
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin("Container.SetViewMode(51)")		
		
def listar_filmes(url):#title
	xbmc.log('SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS    '+url)
	link  = abrir_url(url)
	link = BeautifulSoup(link, convertEntities=BeautifulSoup.HTML_ENTITIES)
	match = link.find('div',{'class':'mw content'}).findAll('a')
	for i in match:
		name = i['title'].encode('utf-8').replace('*e','')
		url = i['href']
		hora = i.strong.text.encode('utf-8').replace('*e','')
		canal = i.h2.text.encode('utf-8').replace('*e','')
		if selfAddon.getSetting('startup') == "0":
			addDir('[COLOR lime]\n|>   [/COLOR]'+'[COLOR darkseagreen]%s[/COLOR]'%canal+'  [COLOR lime]  < - >  [/COLOR]''  [COLOR white]'+hora+'[/COLOR]  ''[COLOR lime]  < - >  [/COLOR]''[COLOR white]'' [COLOR darkseagreen]'+name+'[/COLOR]'+'[COLOR lime]   <|[/COLOR]',base2+url,99,artfolder + 'icon.png')
		elif selfAddon.getSetting('startup') == "1":
			addDir('[COLOR lime]'+canal+'[/COLOR]\n[COLOR darkseagreen]'+hora+'[/COLOR]  | [COLOR white]'+name+'[/COLOR]\n',base2+url,99,artfolder + 'icon.png')
	
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin("Container.SetViewMode(51)")	
	
############################################################################################################
#                                           PLAYER                                                
############################################################################################################		

def pegar_link(url): #98
	xbmc.log('SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS  sssss  '+url)
	link  = abrir_url(url)
	link = BeautifulSoup(link, convertEntities=BeautifulSoup.HTML_ENTITIES)
	match = link.find('ul',{'class':'mw'}).findAll('a')
	for i in match:
		hora = i.div.text.encode('utf-8')
		name = i['title'].encode('utf-8')
		cate = i.h3.text.encode('utf-8')
		url = i['href']
		canals = link.h1.text.encode('utf-8')
		if selfAddon.getSetting('startup') == "0":
			addDir('[COLOR lime]\n|>   [/COLOR]'+'[COLOR darkseagreen]%s[/COLOR]'%name+' [COLOR lime]  < - >  [/COLOR]'' [COLOR white]''[COLOR white]'+hora+'[/COLOR]''[COLOR lime]  < - >  [/COLOR]''[COLOR white]'' [COLOR darkseagreen]'+canals+'[/COLOR]''[COLOR lime]  < - >  [/COLOR]''[COLOR white]'' [COLOR white]'+cate+'[/COLOR]'+'[COLOR lime]   <|[/COLOR]',base2+url,96,artfolder + 'icon.png')
		elif selfAddon.getSetting('startup') == "1":
			addDir('[COLOR darkseagreen]'+canals+'[/COLOR][COLOR lime] | '+cate.lower().capitalize()+'[/COLOR]\n[COLOR white]'+hora+'[/COLOR] | '+name,base2+url,96,artfolder + 'icon.png')
		
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin("Container.SetViewMode(51)")	

	
def description1(url):# 5 
#	if 'description' in description:
	showText(addon_base,url)
	
def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            return 
        except:
            pass	 
	
def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match	        	
	
			
def remove_repetidos(lista):
    l = []
    for i in lista:
        if i not in l:
            l.append(i)
    l
    return l
	
def pegar_player_trailer(url):
	link  = abrir_url(url)
	link = BeautifulSoup(link, convertEntities=BeautifulSoup.HTML_ENTITIES)
	name = link.title.text.encode('utf-8')
	addDir('[COLOR white]PRÓXIMAS EXIBIÇÕES[/COLOR]',url,2,artfolder + 'icon.png',False)	
	addDir(name,url,2,artfolder + 'icon.png',False)
	addDir('                                                                        ',url,2,artfolder + 'icon.png',False)
	match = link.findAll('a',{'class':'devicepadding'})
	for i in match:
		data = i.h2.text.encode('utf-8').replace('Dom','Domingo').replace('Seg','Segunda-feira').replace('Ter','Terça-feira').replace('Qua','Quarta-feira').replace('Qui','Quinta-feira').replace('Sex','Sexta-feira').replace('Sáb','Sábado').replace(',',' , ')
		canal = i.h3.text.encode('utf-8').replace('*e','')
		if selfAddon.getSetting('startup') == "0":
			addDir('[COLOR lime]\n|>   [/COLOR]'+'[COLOR darkseagreen]%s[/COLOR]'%canal+' [COLOR lime]  < - >  [/COLOR]''[COLOR white]'+data+'[/COLOR]'+'[COLOR lime]   <|[/COLOR]','','',artfolder + 'icon.png',False)
		elif selfAddon.getSetting('startup') == "1":
			addDir('[COLOR darkseagreen]'+canal+'[/COLOR]\n[COLOR white]'+data+'[/COLOR]','','',artfolder + 'icon.png',False)
		
		
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin("Container.SetViewMode(51)")	
############################################################################################################
#                                           FUNÇOES FEITAS                                                 #
############################################################################################################		
def setViewMenu():
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		
		opcao = selfAddon.getSetting('menuVisu')
		
		if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
		elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
		elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")
		
def setViewFilmes():
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')

		opcao = selfAddon.getSetting('filmesVisu')

		if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
		elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
		elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")
		elif opcao == '3': xbmc.executebuiltin("Container.SetViewMode(501)")
		elif opcao == '4': xbmc.executebuiltin("Container.SetViewMode(508)")
		elif opcao == '5': xbmc.executebuiltin("Container.SetViewMode(504)")
		elif opcao == '6': xbmc.executebuiltin("Container.SetViewMode(503)")
		elif opcao == '7': xbmc.executebuiltin("Container.SetViewMode(515)")
		
		
def abrir_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def addDir(name,url,mode,iconimage,pasta=True,total=1,plot=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo( type="video", infoLabels={ "title": name, "plot": plot } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok

############################################################################################################
#                                               GET PARAMS                                                 #
############################################################################################################
              
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

      
params=get_params()
url=None
name=None
mode=None
iconimage=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Iconimage: "+str(iconimage)



###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################
#abrir_url('https://goo.gl/oKyPTl')


if mode==None or url==None or len(url)<1:
        print "aqui inica o addon  asdasdsadahlhlhhhjlljhljhjjklhkljhkhjhkhjhj"
        categorias(url)
      #  teste = abrir_url('https://goo.gl/oKyPTl')	


		
	  
elif mode==2: listar_filmes(url)
elif mode==4: categorias(url)
elif mode==5: description1(url)

elif mode==99: pegar_link(url)
elif mode==98: pegar_link_google(url)
elif mode==97: pegar_player_Legendados(url)
elif mode==96: pegar_player_trailer(url)

#########################################          FIM
xbmcplugin.endOfDirectory(int(sys.argv[1]))