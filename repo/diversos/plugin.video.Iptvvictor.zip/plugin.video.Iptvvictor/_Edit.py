import xbmcaddon

MainBase = 'http://iptvvictorapp.ucoz.com.br/Inicial_do_Addon.txt'
addon = xbmcaddon.Addon('plugin.video.Iptvvictor')