import xbmcaddon

MainBase ='https://pastebin.com/raw/NkdXuQNi'
addon = xbmcaddon.Addon('plugin.video.brasilIPTV')